##test
library(sp)
library(gwpcor)
library(doParallel)
library(foreach)
library(GWmodel)
library(tidyverse)
library(sf)

data("meuse")
coordinates(meuse) <- c("x", "y") 
proj4string(meuse) <- CRS("+init=epsg:28992")
meuse_sf <- st_as_sf(meuse)
#sp
res <- gwpcor(sdata = meuse, vars = c("cadmium","copper", "zinc"), method = "pearson", kernel = "bisquare",adaptive = TRUE,bw = 50,longlat = FALSE)

#sf
res2 <- gwpcor(sdata = meuse_sf, vars = c("cadmium","copper", "zinc"), method = "pearson", kernel = "bisquare",adaptive = TRUE,bw = 50,longlat = FALSE)

debug(gwpcor)

#foreach = T
system.time(
  foreach_T <- gwpcor(sdata = meuse, vars = c("cadmium","copper", "zinc"), method = "spearman", kernel = "bisquare",adaptive = TRUE,bw = 50,longlat = FALSE,foreach = T)
)

#foreach = F
system.time(
  foreach_F <- gwpcor(sdata = meuse, vars = c("cadmium","copper", "zinc"), method = "spearman", kernel = "bisquare",adaptive = TRUE,bw = 50,longlat = FALSE,foreach = F)
)

spplot(foreach_T$SDF, c("scorr_cadmium.copper","scorr_cadmium.zinc","scorr_copper.zinc")) #GW-cor
spplot(foreach_F$SDF, c("scorr_cadmium.copper","scorr_cadmium.zinc","scorr_copper.zinc")) #GW-cor


###sf ###
library(sf)
meuse_sf <- st_as_sf(meuse)
debug(gwpcor)

system.time(
foreach_T <- gwpcor(sdata = meuse_sf, vars = c("cadmium","copper", "zinc"), method = "spearman", kernel = "bisquare",adaptive = TRUE,bw = 50,longlat = FALSE,foreach = T)
)
system.time(
  foreach_F <- gwpcor(sdata = meuse_sf, vars = c("cadmium","copper", "zinc"), method = "spearman", kernel = "bisquare",adaptive = TRUE,bw = 50,longlat = FALSE,foreach = F)
)


foreach_F$SDF %>% dplyr::select(scorr_cadmium.copper) %>% plot()
